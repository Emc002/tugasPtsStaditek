<body>

	<div class="container-fluid">
	<h2>DATA MEMBER</h2>
	
		<div class="row">
			<table class="table table-dark table-info table-striped table-hover table-bordered">
			<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/addMember")?>" type="button" class="btn btn-secondary">Add Member</a>
				<thead>
					<tr>
						<th>NO MEMBER</th>
						<th>NAME MEMBER</th>
						<th>PHONE NUMBER</th>
						<th>HOMETOWN</th>
						<th>END DATE</th>
						<th>STATUS</th>
						<th>ACTION</th>
					</tr>
				</thead>

				<tbody>
					<?php
				$N=1;

						foreach($data as $td)
						{
					?>
					<tr>
						<td>
						<?php echo $N++ ?>
						</td>
						<td>
							<?php echo $td->name_registration?>
						</td>
						<td>
							<?php echo $td->phone?>
						</td>
						<td>
							<?php echo $td->hometown?>
						</td>
						<td>
							<?php echo $td->end_date?>
						</td>
            <td>
							<?php echo $td->status_member?>
						</td>
						<td>
						<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/viewOneRegistration/$td->id_member")?>" type="button" class="btn btn-warning">Edit Member</a>
						<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/deleteLibrarian/$td->id_member")?>" type="button" class="btn btn-danger">Delete User</a>
						<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/viewExtensionMember/$td->id_member")?>" type="button" class="btn btn-secondary">Member Extension</a>	
					</td>
					</tr>
					<?php
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</body>

</html>
