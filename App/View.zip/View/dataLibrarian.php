<body>

	<div class="container-fluid">
	<h2>DATA LIBRARIAN</h2>
	
		<div class="row">
			<table class="table table-dark table-info table-striped table-hover table-bordered">
			<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/addLibrarian")?>" type="button" class="btn btn-secondary">Add User</a>
				<thead>
					<tr>
						<th>NO LIBRARIAN</th>
						<th>LIBRARIAN NAME</th>
						<th>GENDER</th>
						<th>EMAIL</th>
						<th>PASSWORD</th>
						<th>ACTION</th>
					</tr>
				</thead>

				<tbody>

					<?php
				$N=1;
						foreach($data as $td)
						{
					?>
					<tr>
						<td>
						<?php echo $N++ ?>
						</td>
						<td>
							<?php echo $td->librarian_name?>
						</td>
						<td>
							<?php echo $td->gender?>
						</td>
						<td>
							<?php echo $td->email?>
						</td>
						<td>
							<?php echo $td->password?>
						</td>
						<td>
						<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/viewOneLibrarian/$td->id_librarian")?>" type="button" class="btn btn-warning">Edit user</a>
						<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/deleteLibrarian/$td->id_librarian")?>" type="button" class="btn btn-danger">Delete User</a>
						</td>
					</tr>
					<?php
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</body>

</html>
