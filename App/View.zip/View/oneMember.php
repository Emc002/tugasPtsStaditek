<div class="container-fluid psion">
  <div class="boxcreate col-12">
    <label class="headtitle">UPDATE Member</label>
    <?php
$arrival = new DateTime();
$arrivalString = $arrival->format("Y-m-d H:i:s");
?>
   <div class="">
      <form method="post" action="<?=\Staditek\App\Core\Router::url("GITHUB/library-framework/Public/updateRegistration/$data->id_registration")?>">
      <div class="form-group f1">
          <label for="name_registration">MEMBER NAME</label>
          <input type="text" class="form-control" value="<?= $data->name_registration ?>" id="name_registration" name="name_registration">
        </div>
        <div class="form-group f1">
          <label for="phone">PHONE</label>
          <input type="text" class="form-control" value="<?= $data->phone ?>" id="phone" name="phone">
        </div>
        <div class="form-group f1">
          <label for="hometown">HOMETOWN</label>
          <input type="text" class="form-control" value="<?= $data->hometown ?>" id="hometown" name="hometown">
        </div>
        <div class="form-group f1">
          <label for="charge">CHARGE</label>
          <input type="text" class="form-control" value="<?= $data->charge ?>" id="charge" name="charge">
        </div>
        <input type="hidden" class="form-control datepicker" value="<?php echo $arrivalString; ?>" id="updated_at" name="updated_at">
       
        <div class="form-group f1">

          <a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/member") ?>" class="btn btn-warning">Back</a>
          <input type="submit" class="btn btn-primary" value="submit">
        </div>
      </form>

    </div>
  </div>
</div>