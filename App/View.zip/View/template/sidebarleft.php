
<div class="container-fluid">
    <div class="row ">

      <div class="col-lg-2 divone">
        <div class="side">
          <div class="row header">
            <div class="col-12 header">
              <h1>LIB-SYS</h1>
            </div>
          </div>

          <div class="row rowside yoxy">
            <div class="col-12 sidemenu yox" id="s1">
              <ul>
                <a href="#">

                  <i class='bx bx-desktop'></i>
                  <a id="changer" href="<?= \Staditek\App\Core\Router::url("GITHUB/LIBRARY-FRAMEWORK2/Public/librarian") ?>">LIBRARY</a>
                  
                </a>
              </ul>
            </div>
            <div class="col-12 sidemenu s2 yox" id="s2">
              <ul>
                <a href="#">
                <i class='bx bx-wallet'></i>
                <a href="<?= \Staditek\App\Core\Router::url("GITHUB/LIBRARY-FRAMEWORK2/Public/member") ?>">MEMBER</a>

              </a>
              
              </ul>
            </div> 
            <div class="col-12 sidemenu s2 yox" id="s2">
              <ul>
                <a href="#">
                <i class='bx bx-wallet'></i>
                <a href="<?= \Staditek\App\Core\Router::url("GITHUB/LIBRARY-FRAMEWORK2/Public/membertrx") ?>">MEMBER TRX</a>

              </a>
              
              </ul>
            </div> 
            <div class="col-12 sidemenu yox" id="s3">
              <ul><a href="#">
                <i class='bx bx-package' ></i>
                <a href="<?= \Staditek\App\Core\Router::url("GITHUB/LIBRARY-FRAMEWORK2/Public/book") ?>">BOOK</a>

              </a></ul>
            </div>

            <div class="col-12 sidemenu yox" id="s3">
              <ul><a href="#">
                <i class='bx bx-package' ></i>
                <a href="<?= \Staditek\App\Core\Router::url("GITHUB/LIBRARY-FRAMEWORK2/Public/subscription") ?>">SUBSCRIPTION</a>

              </a></ul>
            </div>
            <div class="col-12 sidemenu yox" id="s4">
              <ul><a href="#">
                <i class='bx bx-user' ></i>
                <a href="<?= \Staditek\App\Core\Router::url("GITHUB/LIBRARY-FRAMEWORK2/Public/logout")?>">LOG OUT</a>
              </a></ul>
            </div>
          </div>
        </div>
      </div>