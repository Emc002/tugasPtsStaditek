<section class="footer" style="background-color: black; margin-top: 10rem; color: #f2f2f2;">
   
    <footer class="text-center text-dark" style="background-color:#5679bc;">
    
      <div class="p-4 pb-0">
       
        <section class="">
          <p class="d-flex justify-content-center align-items-center">
            <span class="me-3">Register for free</span>
            <button type="button" class="btn btn-outline-dark btn-rounded text-bg-dark">
              Sign up!
            </button>
          </p>
        </section>
       
      </div>
    

      <div class="text-center p-3">
        © 2022 Copyright:
        <a class="text-dark" href="#">STADITEK</a>
      </div>
     
    </footer>
 
  </section>

</body>
</html>