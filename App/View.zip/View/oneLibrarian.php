<div class="container-fluid psion">
  <div class="boxcreate col-12">
    <label class="headtitle">UPDATE LIBRARIAN</label>
    <?php
$arrival = new DateTime();
$arrivalString = $arrival->format("Y-m-d H:i:s");
?>
   <div class="">
      <form method="post" action="<?=\Staditek\App\Core\Router::url("GITHUB/library-framework/Public/updateLibrarian/$data->id_librarian")?>">
      <div class="form-group f1">
          <label for="nama_laptop">LIBRARIAN NAME</label>
          <input type="text" class="form-control" value="<?= $data->librarian_name ?>" id="librarian_name" name="librarian_name">
        </div>
        <div class="form-group f1">
          <label for="seri_laptop">GENDER</label>
          <select name="gender">
            <option value="<?= $data->jk ?>" selected><?= $data->gender ?></option>
            <option value="MAN">MAN</option>
            <option value="WOMAN">WOMAN</option>
          </select>
        </div>
        <div class="form-group f1">
          <label for="nama_laptop">EMAIL</label>
          <input type="text" class="form-control" value="<?= $data->email ?>" id="email" name="email">
        </div>
        <div class="form-group f1">
          <label for="nama_laptop">PASSWORD</label>
          <input type="text" class="form-control" value="<?= $data->password ?>" id="password" name="password">
        </div>
        <input type="hidden" class="form-control datepicker" value="<?php echo $arrivalString; ?>" id="updated_at" name="updated_at">
       
        <div class="form-group f1">

          <a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/librarian") ?>" class="btn btn-warning">Back</a>
          <input type="submit" class="btn btn-primary" value="submit">
        </div>
      </form>

    </div>
  </div>
</div>