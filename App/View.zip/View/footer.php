<footer class="footer">
	  <div class="container" style="text-align:center;">
        <span>STADITEK @<?php echo date('Y'); ?></span>
      </div>
    </footer>
  </body>
</html>