<!DOCTYPE html>
<html lang="en">
<?php error_reporting(E_ALL ^ E_WARNING); ?>

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href=
"https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<title>User Data</title>
  <style>
    .navbar{
      margin-bottom: 3rem;
    }

    .btn{
      margin-top: 1rem;
      margin-bottom: 1rem;
      margin-left: 1rem;
    }

    th{
      text-align: center;
    }

    td{
      text-align: center;
      vertical-align: middle !important;
    }

    .boxcreate{
        background-color: #343a40;
        height: 100%;
        width: 60vw;
        margin-left: 15rem;
        box-shadow: -0.7rem 2rem 1rem 1rem rgba(0, 0, 0, 0.47);
        padding: 1rem 5rem 2rem 5rem;
        border-radius: 1rem;
        color: white;
}

body {
  background-color: #26272c;
  color: white;
}

.geser{
  position: absolute;
  right: 1rem;
}





  
  </style>
</head>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">L-DATA</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/librarian") ?>">LIBRARIAN <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/member") ?>">MEMBER</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/book") ?>">BOOK</a>
      </li>
      <li class="nav-item active">
      <a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/logout")?>" class="geser nav-link">LOG OUT</a>
      </li>

   
    </ul>
  </div>
</nav>
