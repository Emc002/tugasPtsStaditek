<body>
	<div class="container-fluid">
	<h2>DATA USER</h2>
	
		<div class="row">
			<table class="table table-dark table-info table-striped table-hover table-bordered">
			<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/addBook")?>" type="button" class="btn btn-secondary">Add Book</a>
				<thead>
					<tr>
						<th>NO BOOK</th>
						<th>ISBN</th>
						<th>TITLE</th>
						<th>PRICE</th>
						<th>MAX TIME LIMIT/DAY</th>
						<th>ACTION</th>
					</tr>
				</thead>

				<tbody>
					<?php
						$N=1;
						foreach($data as $td)
						{
					?>
					<tr>
						<td>
							<?php echo $N++ ?>
						</td>
						<td>
							<?php echo $td->isbn?>
						</td>
						<td>
							<?php echo $td->title?>
						</td>
						<td>
							<?php echo $td->price?>
						</td>
						<td>
							<?php echo $td->max_borrowing?>
						</td>
						<td>
						<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/viewOneBook/$td->id_book")?>" type="button" class="btn btn-warning">Edit user</a>
						<a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/deleteBook	/$td->id_book")?>" type="button" class="btn btn-danger">Delete User</a>
						</td>
					</tr>
					<?php
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</body>

</html>
