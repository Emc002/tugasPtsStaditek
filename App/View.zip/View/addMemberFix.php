<div class="container-fluid psion">
  <div class="boxcreate col-12">
    <label class="headtitle">ADD MEMBER</label>
    <?php
$arrival = new DateTime();
$arrivalString = $arrival->format("Y-m-d H:i:s");
?>

    <div class="">
      <form method="post" action="<?=\Staditek\App\Core\Router::url("GITHUB/library-framework/Public/saveMember") ?>">
      
      <div class="form-group f1">
          <label for="seri_laptop">NAME MEMBER</label>
          <select name="id_registration">
          <option value="none" selected>STATUS</option>

          <?php
						foreach($data as $td)
						{
					?>
            <option value="<?php echo $td->id_registration?>"><?php echo $td->name_registration?></option>
            <?php } ?>
          </select>
        </div>

     
        <div class="form-group f1">
          <label for="name_registration">END DATE</label>
          <input type="date" class="form-control" id="end_date" name="end_date">
        </div>
        <div class="form-group f1">
          <label for="seri_laptop">STATUS</label>
          <select name="status_member">
            <option value="none" selected>STATUS</option>
            <option value="active">active</option>
            <option value="non active">non active</option>
          </select>
        </div>
          <input type="hidden" class="form-control" value="<?php echo $arrivalString; ?>" id="date" name="date">
        <div class="form-group f1">

          <a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/member") ?>" class="btn btn-warning">Back</a>
          <input type="submit" class="btn btn-primary" value="submit">
        </div>

      </form>

    </div>
  </div>
</div>