<div class="container-fluid psion">
  <div class="boxcreate col-12">
    <label class="headtitle">EXTENSION MEMBER</label>
    <?php
$arrival = new DateTime();
$arrivalString = $arrival->format("Y-m-d H:i:s");
?>
   <div class="">
      <form method="post" action="<?=\Staditek\App\Core\Router::url("GITHUB/library-framework/Public/updateExtensionMember/$data->id_member")?>">
      <div class="form-group f1">
          <label for="name_registration">END DATE</label>
          <input type="text" class="form-control" value="<?= $data->end_date ?>" id="end_date" name="end_date">
        </div>
        <div class="form-group f1">
          <label for="seri_laptop">STATUS</label>
          <select name="status_member">
            <option value="<?= $data->status_member ?>" selected><?php echo $data->status_member ?></option>
            <option value="active">active</option>
            <option value="non active">non active</option>
          </select>
        </div>
        <input type="hidden" class="form-control datepicker" value="<?php echo $arrivalString; ?>" id="updated_at" name="updated_at">
       
        <div class="form-group f1">

          <a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/member") ?>" class="btn btn-warning">Back</a>
          <input type="submit" class="btn btn-primary" value="submit">
        </div>
      </form>

    </div>
  </div>
</div>