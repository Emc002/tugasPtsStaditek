<div class="container-fluid psion">
  <div class="boxcreate col-12">
    <label class="headtitle">ADD BOOK</label>
    <?php
$arrival = new DateTime();
$arrivalString = $arrival->format("Y-m-d H:i:s");
?>

    <div class="">
      <form method="post" action="<?=\Staditek\App\Core\Router::url("GITHUB/library-framework/Public/saveBook") ?>">
        <div class="form-group f1">
          <label for="isbn">ISBN</label>
          <input type="text" class="form-control" id="isbn" name="isbn">
        </div>
        <div class="form-group f1">
          <label for="title">TITLE</label>
          <input type="text" class="form-control" id="title" name="title">
        </div>
        <div class="form-group f1">
          <label for="price">PRICE</label>
          <input type="text" class="form-control" id="price" name="price">
        </div>
        <div class="form-group f1">
          <label for="max_borrowing">MAX TIME LIMIT/DAY</label>
          <input type="text" class="form-control" id="max_borrowing" name="max_borrowing">
        </div>

          <input type="hidden" class="form-control datepicker" value="<?php echo $arrivalString; ?>"  id="date" name="date">      
        <div class="form-group f1">

          <a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/book") ?>" class="btn btn-warning">Back</a>
          <input type="submit" class="btn btn-primary" value="submit">
        </div>

      </form>

    </div>
  </div>
</div>