<div class="container-fluid psion">
  <div class="boxcreate col-12">
    <label class="headtitle">UPDATE BOOK</label>
    <?php
$arrival = new DateTime();
$arrivalString = $arrival->format("Y-m-d H:i:s");
?>
   <div class="">
      <form method="post" action="<?=\Staditek\App\Core\Router::url("GITHUB/library-framework/Public/updateBook/$data->id_book")?>">
      <div class="form-group f1">
          <label for="isbn">ISBN</label>
          <input type="text" class="form-control" value="<?= $data->isbn ?>" id="isbn" name="isbn">
        </div>
        <div class="form-group f1">
          <label for="title">TITLE</label>
          <input type="text" class="form-control" value="<?= $data->title ?>" id="title" name="title">
        </div>
        <div class="form-group f1">
          <label for="price">PRICE</label>
          <input type="text" class="form-control" value="<?= $data->price ?>" id="price" name="price">
        </div>
        <div class="form-group f1">
          <label for="max_borrowing">MAX TIME LIMIT/DAY</label>
          <input type="text" class="form-control" value="<?= $data->max_borrowing ?>" id="max_borrowing" name="max_borrowing">
        </div>
      
        <input type="hidden" class="form-control datepicker" value="<?php echo $arrivalString; ?>" id="updated_at" name="updated_at">
       
        <div class="form-group f1">

          <a href="<?= \Staditek\App\Core\Router::url("GITHUB/library-framework/Public/librarian") ?>" class="btn btn-warning">Back</a>
          <input type="submit" class="btn btn-primary" value="submit">
        </div>
      </form>

    </div>
  </div>
</div>